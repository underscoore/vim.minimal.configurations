vim.cmd [[
  let g:mkdp_theme = 'light'
  let g:mkdp_command_for_global = 1
]]
